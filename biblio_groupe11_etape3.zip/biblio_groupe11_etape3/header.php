<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<header>
		<h1> <a href="index.html"><img src="../image/Logo.png" height="120" width="120"></a>Manga References</h1>
	<div class="option"><a href="contact.php">Contact</a></div>
	</header>
</body>
</html>